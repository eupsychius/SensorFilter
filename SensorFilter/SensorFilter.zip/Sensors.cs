﻿public class Sensor
{
    public int      SensorId        { get; set; }
    public int      Channel         { get; set; }
    public string   SerialNumber    { get; set; }
    public string   Type            { get; set; }
    public string   Model           { get; set; }
}
